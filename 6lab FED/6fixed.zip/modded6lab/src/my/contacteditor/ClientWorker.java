package my.contacteditor;

import java.net.DatagramPacket;
import java.net.DatagramSocket;

public class ClientWorker implements Runnable {

    private int port;

    public ClientWorker(int port) {
        this.port = port;
    }

    @Override
    public void run() {

        try {
            DatagramSocket socket = new DatagramSocket(port);

            while (true) {

                byte[] buffer = new byte[1024];

                DatagramPacket packet =
                        new DatagramPacket(buffer, buffer.length);

                socket.receive(packet);
System.out.println(
    "[CLIENT " + port + "] Пакет получен"
);

System.out.println(
    "[CLIENT " + port + "] Адрес отправителя: "
    + packet.getAddress()
);

System.out.println(
    "[CLIENT " + port + "] Порт отправителя: "
    + packet.getPort()
);
                String msg =
                        new String(packet.getData(), 0, packet.getLength());

                System.out.println(
                        "Клиент " + port + " получил задачу: " + msg);

                String[] parts = msg.split(";");

                int row = Integer.parseInt(parts[0]);

                double lower = Double.parseDouble(parts[1]);
                double upper = Double.parseDouble(parts[2]);
                double range = Double.parseDouble(parts[3]);

                int THREADS = 7;

                double step = (upper - lower) / THREADS;

                Thread[] threads = new Thread[THREADS];
                IntegralTask[] tasks = new IntegralTask[THREADS];

                double start = lower;

                for (int i = 0; i < THREADS; i++) {

                    double end =
                            (i == THREADS - 1)
                            ? upper
                            : start + step;

                    tasks[i] =
                            new IntegralTask(start, end, range);

                    threads[i] =
                            new Thread(tasks[i]);

                    threads[i].start();

                    start = end;
                }

                double total = 0;

                for (int i = 0; i < THREADS; i++) {

                    threads[i].join();

                    total += tasks[i].getResult();
                    System.out.println(
    "[CLIENT " + port + "] partial[" + i + "] = "
    + tasks[i].getResult()
);
                }

                System.out.println(
                        "Клиент " + port +
                        " вычислил результат: " + total);

                String result = row + ";" + total;

                byte[] sendData = result.getBytes();

                DatagramPacket response =
                        new DatagramPacket(
                                sendData,
                                sendData.length,
                                packet.getAddress(),
                                packet.getPort()
                        );

                Thread.sleep(2000);

                socket.send(response);
System.out.println(
    "[CLIENT " + port + "] Ответ отправлен"
);

System.out.println(
    "[CLIENT " + port + "] result = " + result
);

System.out.println(
    "[CLIENT " + port + "] target port = "
    + packet.getPort()
);
                System.out.println(
                        "Клиент " + port +
                        " отправил результат серверу");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}